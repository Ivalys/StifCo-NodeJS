// Variables.
var http = require('http'); // Permet de créer le serveur
var port = 8080; // Port for the server.

// Ranged variable (used in controllers, models & functions)
colors = require('colors/safe'); // Permet de mettre des couleurs dans la fonction logServer.
url = require('url'); // Permet de récupérer l'URL
querystring = require('querystring'); // GET & POST
express = require('express'); // Framework Express -> Permet de créer le serveur rapidement, et intégrer un moteur de template
var session = require('express-session'); // Session avec express.
twig = require('twig'); // Views (/views) will be loaded by Twig.
img = require('serve-static'); // Charge le middleware qui permet d'intégrer les images.
bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
mysql = require('mysql'); // Charge MySQL pour NodeJS.
sql = require('./models/mysql'); // Définition des modèles et de la connexion.
app = express(); // Créer le serveur et le stock dans la variable "app".
app.use(session({secret: 'appnodejs'})) // Lancement de la session
urlencodedParser = bodyParser.urlencoded({ extended: false });

// Load pictures/CSS. (Les liens doivent être simplement le nom de l'image. ex : src="img.gif")
app.use(express.static(__dirname + '/views/img'));
app.use(express.static(__dirname + '/views/css'));

// Controllers (controllers).
var controllers = {anonymous:require('./controllers/anonymous'),
		   user:require('./controllers/user'),
		   unknow:require('./controllers/unknow')};

// Launching the server..
app.listen(port);

// Writing documentation on console..
console.log("\n");
console.log("****************************************\n* Server is launched on port "+port+" !\n****************************************\nDifferents colors :\n- "+colors.green('Green : HTTP Request succeed')+"\n- "+colors.red('Red : HTTP Request failed')+"\n- "+colors.cyan('Cyan : SQL Request done')+"\n- "+colors.yellow('Yellow : SQL Request returning NULL')+"\n****************************************\n");
