function logServer(req, code)
{
	var page = url.parse(req.url).pathname;
	var ip = req.connection.remoteAddress;
	console.log('Requested URL : ['+page+'] from client IP ['+ip+'] with HTTP-Code ['+code+'].');
}
