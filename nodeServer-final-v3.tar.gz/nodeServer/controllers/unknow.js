var functions = require('../functions/functions.js');

function routeUnknow()
{
	app.use(function(req, res, next)
	{
		functions.logServer(req, 404);

	    	res.setHeader('Content-Type', 'text/html');
		res.status(404).send('<h1>Erreur 404 - Page introuvable !</h1>- <a href="/">Retourner &agrave; l`accueil')
	});
}

routeUnknow();
